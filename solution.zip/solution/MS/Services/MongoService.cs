﻿using DesafioBTG.MS.Models;
using DesafioBTG.MS.Utils;
using MongoDB.Driver;

namespace DesafioBTG.MS.Services
{
    public class MongoService
    {
        private readonly IMongoCollection<Pedido> _pedidos;

        public MongoService()
        {
            var configuration = AppSettings.Configuration;

            var client = new MongoClient(configuration["MongoDB:ConnectionString"]);
            var database = client.GetDatabase(configuration["MongoDB:DatabaseName"]);
            _pedidos = database.GetCollection<Pedido>(configuration["MongoDB:CollectionName"]);
        }

        public void InserirPedido(Pedido pedido)
        {
            _pedidos.InsertOne(pedido);
            Console.WriteLine($"Pedido {pedido.CodigoPedido} inserido com sucesso.");
        }
    }
}
