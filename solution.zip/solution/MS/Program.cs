﻿using DesafioBTG.MS.Models;
using DesafioBTG.MS.Services;
using DesafioBTG.MS.Utils;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Microsoft.Extensions.Configuration;
using System.Text;
using System.Text.Json;

var configuration = AppSettings.Configuration;
var rabbitSection = configuration.GetSection("RabbitMQ");

if (!rabbitSection.Exists())
    throw new InvalidOperationException("Parâmetro RabbitMQ não encontrada no appsettings.json");

var rabbitSettings = new RabbitMqSettings
{
    HostName = rabbitSection["HostName"] ?? "localhost",
    QueueName = rabbitSection["QueueName"] ?? "pedidos"
};

var factory = new ConnectionFactory() { HostName = rabbitSettings.HostName };
using var connection = factory.CreateConnection();
using var channel = connection.CreateModel();

channel.QueueDeclare(queue: rabbitSettings.QueueName,
                     durable: true,
                     exclusive: false,
                     autoDelete: false,
                     arguments: null);

var mongoService = new MongoService();

var consumer = new EventingBasicConsumer(channel);
consumer.Received += (model, ea) =>
{
    var body = ea.Body.ToArray();
    var message = Encoding.UTF8.GetString(body);

    try
    {
        var pedido = JsonSerializer.Deserialize<Pedido>(message, new JsonSerializerOptions
        { 
            PropertyNameCaseInsensitive = true
        });
        if (pedido != null)
        {
            if (pedido.CodigoPedido > 0)
            {
                mongoService.InserirPedido(pedido);
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Erro ao processar mensagem: {ex.Message}");
    }
};

channel.BasicConsume(queue: "pedidos",
                     autoAck: true,
                     consumer: consumer);

Console.WriteLine("Microsserviço aguardando mensagens da fila 'pedidos'...");
Console.ReadLine();
